// import { moduleMetadata } from '@storybook/angular';
// import { CommonModule } from '@angular/common';
// // also exported from '@storybook/angular' if you can deal with breaking changes in 6.1
// import { Story, Meta } from '@storybook/angular/types-6-0';
// import { withDesign } from 'storybook-addon-designs';

// import Figma from './figma.component';

// export default {
//   title: 'JA Design System/Components/Figma',
//   component: Figma,
//   decorators: [
//     moduleMetadata({
//       declarations: [],
//       imports: [CommonModule],
//     }),
//     withDesign,
//   ],
// } as Meta;

// const Template: Story<Figma> = (args: Figma) => ({
//   component: Figma,
//   props: args,
// });

// export const FigmaPre = Template.bind({});
// FigmaPre.args = {
//   design: {
//     type: 'figma',
//     url:
//       'https://www.figma.com/file/P2MRmRHrWHEZL9Cfd9X7Nk/JobAdder-Scales-Design-Library-V0.1?node-id=99%3A0',
//   },
// };
